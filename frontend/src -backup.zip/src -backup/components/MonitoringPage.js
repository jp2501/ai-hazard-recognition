import React from "react";
import StreamCard from "./StreamCard";

const MonitoringPage = () => {
  return (
    <div className="monitoring-grid">
      <StreamCard streamId={1} />
      <StreamCard streamId={2} />
    </div>
  );
};

export default MonitoringPage;
