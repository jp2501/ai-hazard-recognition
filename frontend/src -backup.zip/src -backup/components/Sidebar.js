import React from "react";

const Sidebar = ({ onChangeView }) => (
  <div className="w-48 bg-gray-200 p-4">
    <h1 className="font-bold text-xl mb-4">Hazard Monitoring</h1>
    <ul className="space-y-2">
      <li><button onClick={() => onChangeView("monitor")}>Monitor</button></li>
      <li><button onClick={() => onChangeView("dashboard")}>Dashboard</button></li>
    </ul>
  </div>
);

export default Sidebar;
