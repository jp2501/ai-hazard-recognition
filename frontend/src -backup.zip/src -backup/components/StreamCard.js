import React, { useState, useRef } from "react";
import { uploadVideo, setPolygon, setConfidence } from "../api";

const SERVER_URL = "http://127.0.0.1:8000";
const defaultPolygon = [
  [607.5, 25.65625], [637.5, 94.65625], [472.5, 480.65625],
  [180.5, 471.65625], [127.5, 384.65625], [520.5, 32.65625],
];


const StreamCard = ({ streamId, videoUploaded, setVideoUploaded }) => {
  const [points, setPoints] = useState(defaultPolygon);
  const [dragIndex, setDragIndex] = useState(null);
  const [confidence, setConfidenceVal] = useState(0.5);
  const [qualityHigh, setQualityHigh] = useState(false);
  const [sharpness, setSharpness] = useState(1.0);
  const [gamma, setGamma] = useState(1.0);
  const [backgroundUrl, setBackgroundUrl] = useState(null);
  const svgRef = useRef(null);


  const getStreamURL = () =>
    `${SERVER_URL}/stream_${streamId}?quality=${qualityHigh ? "high" : "low"}&sharpness=${sharpness}&gamma=${gamma}`;

  const handleMouseDown = (index) => setDragIndex(index);
  const handleMouseUp = () => setDragIndex(null);
  const handleMouseMove = (e) => {
    if (dragIndex === null) return;
    const svg = svgRef.current;
    const rect = svg.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const updated = [...points];
    updated[dragIndex] = [x, y];
    setPoints(updated);
  };

  const handleApplyPolygon = async () => {
    await setPolygon(streamId, points);
  };

  const handleVideoUpload = async (e) => {
    const file = e.target.files[0];
    await uploadVideo(streamId, file);
    setVideoUploaded(true);
    setBackgroundUrl(`${SERVER_URL}/get_screenshot_${streamId}?t=${Date.now()}`);

  };

  const handleResetStream = () => {
    setVideoUploaded(false);
  };

  const handleConfidenceChange = async (e) => {
    const val = parseFloat(e.target.value);
    setConfidenceVal(val);
    await setConfidence(streamId, val);
  };

  return (
    <div className="stream-card">
      <h3>
        <span role="img" aria-label="camera">📷</span> Camera {streamId}
      </h3>

      <div className="canvas-wrapper">
        <svg
          ref={svgRef}
          width={640}
          height={480}
          className="canvas"
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
        >
          {backgroundUrl && (
            <image
              href={backgroundUrl}
              x="0"
              y="0"
              width="640"
              height="480"
              preserveAspectRatio="xMidYMid slice"
            />
          )}
          <polygon
            points={points.map(([x, y]) => `${x},${y}`).join(" ")}
            fill="rgba(255, 0, 0, 0.3)"
            stroke="red"
            strokeWidth={2}
          />
          {points.map(([x, y], i) => (
            <circle
              key={i}
              cx={x}
              cy={y}
              r={6}
              fill="blue"
              onMouseDown={() => handleMouseDown(i)}
            />
          ))}
        </svg>
      </div>

      <div className="controls">
        <input type="file" onChange={handleVideoUpload} />
        <button onClick={handleApplyPolygon}>Apply Polygon</button>
        <button onClick={handleResetStream}>
          <span role="img" aria-label="stop">🛑</span> Stop & Upload New
        </button>
      </div>

      <div className="confidence">
        <label>Confidence: {confidence.toFixed(2)}</label>
        <input
          type="range"
          min="0.1"
          max="1.0"
          step="0.05"
          value={confidence}
          onChange={handleConfidenceChange}
        />
      </div>

      <div className="video-wrapper">
        {videoUploaded && (
          <img
            src={getStreamURL()}
            alt={`Stream ${streamId}`}
            className="video"
          />
        )}
      </div>

      <div className="quality-toggle">
        <label>Video Quality: {qualityHigh ? "High" : "Low"}</label>
        <input
          type="checkbox"
          checked={qualityHigh}
          onChange={() => setQualityHigh(!qualityHigh)}
        />
      </div>

      <div className="sliders">
        <label> Sharpness: {sharpness.toFixed(2)}</label>
        <input
          type="range"
          min="0.5"
          max="2.0"
          step="0.1"
          value={sharpness}
          onChange={(e) => setSharpness(parseFloat(e.target.value))}
        />
        <label> Gamma: {gamma.toFixed(2)}</label>
        <input
          type="range"
          min="0.8"
          max="1.5"
          step="0.05"
          value={gamma}
          onChange={(e) => setGamma(parseFloat(e.target.value))}
        />
      </div>
    </div>
  );
};

export default StreamCard;
